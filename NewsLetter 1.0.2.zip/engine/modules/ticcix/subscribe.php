<?php
/*
=====================================================
 Ticcix 
-----------------------------------------------------
 https://github.com/Ticcix / https://Ticcix.Com/
-----------------------------------------------------
 Copyright (c) 2024 Ticcix
=====================================================
 This code is protected by copyright
=====================================================
 File: subscribe.php
-----------------------------------------------------
 Use: subscribe form for Ticcix
=====================================================

*/
function message($status, $header, $message, $url = '')
	{
		exit(json_encode(['status' => $status, 'header' => $header, 'message' => $message, 'url' => $url]));
	}

	function location($url)
	{
		exit(json_encode(['url' => $url]));
	}

if (!defined('DATALIFEENGINE'))
	die("Go fuck yourself!");



include "engine/data/config.subscribe.php";

if (isset($_POST['email']) ) {

		$email = $_POST['email']; 
    if (empty($email)) {
        message('error', "{$lang['error']}", "{$lang['subscribe_maild']}");
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        message('error', "{$lang['error']}", "{$lang['subscribe_mailv']}", "");
    } 
    $date = date("Y-m-d H:i:s");


		$check = $db->super_query("SELECT * FROM " . PREFIX . "_subscribeusers WHERE signup_email_address = '$email'");

		
		if ($check['signup_email_address'] != $email) {

		$result = $db->query("INSERT INTO " . PREFIX . "_subscribeusers (signup_email_address,signup_date , active) VALUES('$email','$date' , '1')");
			
		if ($result == true) {
                
				message('success', "{$lang['success']}", "{$lang['subscribe_mails']}", "");

			} else {
				message('error', "{$lang['error']}", "{$lang['subscribe_mailw']}", "");
			}

		} else {
      if ($check['active'] == 0) {
        $result = $db->query("UPDATE " . PREFIX . "_subscribeusers SET active = '1' WHERE signup_email_address = '$email'");
        if ($result == true) {
          message('success', "{$lang['success']}", "{$lang['subscribe_mails']}", "");
        } else {
          message('error', "{$lang['error']}", "{$lang['subscribe_mailaw']}", "");
        }
        }else {
          message('error', "{$lang['error']}", "{$lang['subscribe_mailals']}", "");
        }

      }
	}

$Config  = array(
	'active' => $subscribe_config['active'],
	'template' => !empty($template) ? $template : 'subscribe',
	'cachePrefix' => !empty($cachePrefix) ? $cachePrefix : 'subscribe',
	'cacheSuffix' => !empty($cacheSuffix) ? true : false
);
$cacheName = md5(implode('_', $Config));
$subscribe  = false;
$subscribe  = dle_cache($Config['cachePrefix'], $cacheName . $config['skin'], $Config['cacheSuffix']);

if (!$subscribe AND $subscribe_config['active'] == '1') {
	if (file_exists(TEMPLATE_DIR . '/' . $Config['template'] . '.tpl')) {
		if (!isset($tpl)) {
			$tpl      = new dle_template();
			$tpl->dir = TEMPLATE_DIR;
		} else {
			$tpl->result['myModule'] = '';
		}
		$tpl->load_template($Config['template'] . '.tpl');
		$tpl->compile('subscribe');
		$subscribe = $tpl->result['subscribe'];
		create_cache($Config['cachePrefix'], $subscribe, $cacheName . $config['skin'], $Config['cacheSuffix']);
		$tpl->clear();
	} else {
		$subscribe = '<b style="color:red">'. $lang[subscribe_tpl_error] .': ' . $config['skin'] . '/' . $Config['template'] . '.tpl</b>';
	}
} else {
  echo '<b style="color:red">'. $lang[subscribe_active_error] .'</b>';
}
echo $subscribe;
?>


