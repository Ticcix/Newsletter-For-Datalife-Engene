<?PHP
/*
=====================================================
 Ticcix
-----------------------------------------------------
 https://github.com/Ticcix || https://ticcix.com
-----------------------------------------------------
 Copyright (c) 2024 Ticcix
=====================================================
 This code is protected by copyright
=====================================================
 File: subscribeusers.php
-----------------------------------------------------
 Use: Configure subscribe users form in admin
=====================================================
*/

if( !defined( 'DATALIFEENGINE' ) OR !defined( 'LOGGED_IN' ) ) {
	header( "HTTP/1.1 403 Forbidden" );
	header ( 'Location: ../../' );
	die( "Hacking attempt!" );
}

if( $member_id['user_group'] != 1 ) {
	msg( "error", $lang['index_denied'], $lang['index_denied'] );
}

require_once (ENGINE_DIR . '/data/config.subscribe.php');
if( $config['allow_admin_wysiwyg'] == 1 ) {

		$js_array[] = "engine/skins/codemirror/js/code.js";

		$js_array[] = "engine/editor/jscripts/froala/editor.js";

		$js_array[] = "engine/editor/jscripts/froala/languages/{$lang['wysiwyg_language']}.js";

		$css_array[] = "engine/editor/jscripts/froala/css/editor.css";

	}

	

	if( $config['allow_admin_wysiwyg'] == 2 ) {

		$js_array[] = "engine/editor/jscripts/tiny_mce/tinymce.min.js";

	}

	

	if( !$config['allow_admin_wysiwyg'] ) {

		$js_array[] = "engine/classes/js/typograf.min.js";

	}

	

	$js_array[] = "engine/classes/js/sortable.js";

	$js_array[] = "engine/classes/uploads/html5/fileuploader.js";
	

  $db->query( "SELECT * FROM " . USERPREFIX . "_subscribeusers  WHERE active = '1' ORDER BY id DESC" );

	while($row = $db->get_row()){



		$row['signup_email_address'] = htmlspecialchars( stripslashes($row['signup_email_address']), ENT_QUOTES, $config['charset'] );
   
	
			$entries .= "<div class=\"col-sm-3\"><label class=\"checkbox\"><input type=\"checkbox\" name=\"recipients[]\" value=\"{$row['signup_email_address']}\"><span class=\"indicator\"></span>{$row['signup_email_address']}</label></div>";

	
}


if($action == "sending") {
	
if( $_REQUEST['user_hash'] == "" or $_REQUEST['user_hash'] != $dle_login_hash ) {
		
		die( "Hacking attempt! User not found" );
	
	}




$home_title = $subscribe_config['home_title'];

$url = $subscribe_config['http_home_url'];

$date = $subscribe_config['timestamp'];



    $recipients = $_POST['recipients'];
    if (empty($_POST['recipients']) OR empty($_POST['message']) or empty($_POST['subject'])) {
        msg( "error", $lang['addnews_error'], $lang['empty'], "?mod=subscribeusers" );
    }
    $subject = $_POST['subject'];

    $message = $_POST['message'];
		
    $sendermail = $subscribe_config['mail'];
   

    $headers = 'From: '.$sendermail .'' . "\r\n" .

        'Content-Type: text/html; charset=UTF-8' . "\r\n" .

        'X-Mailer: PHP/' . phpversion();



    $success = true;



    foreach ($recipients as $recipient) {
     
			$db->query( "SELECT * FROM " . USERPREFIX . "_subscribeusers  WHERE signup_email_address = '{$recipient}'" );

	while($row = $db->get_row()){



		$user_id = $row['id'];
   
}

			  $hash = md5( SECURE_AUTH_KEY . $_SERVER['HTTP_HOST'] . $user_id  . $config['key'] );


				$unsubscribe_link = $url . "index.php?do=unsubscribe&user_id=" . $user_id . "&hash=" . $hash;


      $htmlMessage = '' . $message . ' <a style="text-decoration: none; color:red" href="'.$unsubscribe_link.'">Unsubscribe</a> ';

        if (!mail(trim($recipient), $subject, $htmlMessage, $headers)) {
    
            $success = false;

        }

    }
		if ($success) {
      
			$db->query( "UPDATE " . USERPREFIX . "_subscribeusers  SET `hash` = '{$hash}' WHERE `signup_email_address` = '{$recipient}'" );

		
        msg( "success", $lang['media_upload_st9'], $lang['nl_sendet'], "?mod=subscribeusers" );


    } else {

       msg( "success", $lang['media_upload_st9'], $lang['nl_sendet'], "?mod=subscribeusers" );

    }

	}


if( $action == "save" ) {

	if( $_REQUEST['user_hash'] == "" or $_REQUEST['user_hash'] != $dle_login_hash ) {
		
		die( "Hacking attempt! User not found" );
	
	}

	$db->query( "INSERT INTO " . USERPREFIX . "_admin_logs (name, date, ip, action, extras) values ('".$db->safesql($member_id['name'])."', '{$_TIME}', '{$_IP}', '57', '')" );
	
	$save_con = $_POST['save_con'];

	
	$find = array();
	$replace = array();
	
	$find[] = "'\r'";
	$replace[] = "";
	$find[] = "'\n'";
	$replace[] = "";
	
	$save_con = $save_con + $subscribe_config;
	
	$handler = fopen( ENGINE_DIR . '/data/config.subscribe.php', "w" );
	
	fwrite( $handler, "<?PHP \n\n////Subscribe form Configurations\n\n\$subscribe_config = array (\n\n" );
	foreach ( $save_con as $name => $value ) {
		
		$value = preg_replace( $find, $replace, $value );

		$value = str_replace( "$", "&#036;", $value );

		$value = str_replace( "{", "&#123;", $value );

		$value = str_replace( "}", "&#125;", $value );

		$value = str_replace( chr(0), "", $value );

		$value = str_replace( chr(92), "", $value );

		$value = str_ireplace( "decode", "dec&#111;de", $value );

		

		$name = preg_replace( $find, $replace, $name );

		$name = str_replace( "$", "&#036;", $name );

		$name = str_replace( "{", "&#123;", $name );

		$name = str_replace( "}", "&#125;", $name );

		$name = str_replace( chr(0), "", $name );

		$name = str_replace( chr(92), "", $name );

		$name = str_replace( '(', "", $name );

		$name = str_replace( ')', "", $name );

		$name = str_ireplace( "decode", "dec&#111;de", $name );
		
		fwrite( $handler, "'{$name}' => '{$value}',\n\n" );
	
	}
	fwrite( $handler, ");\n\n?>" );
	fclose( $handler );
	
	clear_cache();
	
	if (function_exists('opcache_reset')) {
		opcache_reset();
	}
	
	msg( "success", $lang['opt_sysok'], $lang['opt_sysok_1'], "?mod=subscribeusers" );
}



	echoheader( "<i class=\"fa fa-user-circle-o position-left\"></i><span class=\"text-semibold\">{$lang['header_subscribeusers']}</span>", $lang['opt_subscribeusersconf'] );



function showRow($title = "", $description = "", $field = "", $class = "") {
	echo "<tr>
       <td class=\"col-xs-6 col-sm-6 col-md-7\"><div class=\"media-heading text-semibold\">{$title}</div><span class=\"text-muted text-size-small hidden-xs\">{$description}</span></td>
       <td class=\"col-xs-6 col-sm-6 col-md-5\">{$field}</td>
       </tr>";
}

function makeCheckBox($name, $selected) {
	$selected = $selected ? "checked" : "";
	
	return "<input class=\"switch\" type=\"checkbox\" name=\"$name\" value=\"1\" {$selected}>";
}

function makeDropDown($options, $name, $selected) {
	$output = "<select class=\"uniform\" name=\"$name\">\r\n";
	foreach ( $options as $value => $description ) {
		$output .= "<option value=\"$value\"";
		if( $selected == $value ) {
			$output .= " selected ";
		}
		$output .= ">$description</option>\n";
	}
	$output .= "</select>";
	return $output;
}

echo <<<HTML
<form action="?mod=subscribeusers&action=save" name="conf" id="conf" method="post">
<div class="panel panel-default">
  <div class="panel-heading">
    {$lang['panel_subscribeusers']}
  </div>
  <div class="table-responsive">
  <table class="table table-striped">
      <thead>
      <tr>
        <th>{$lang['conf_subscribeusers']}</th>
        <th></th>
      </tr>
      </thead>
HTML;
showRow( $lang['subsc_onoff'], $lang['subsc_onoffdesc'], makeDropDown( array ("1" => "On", "0" => "Off" ), "save_con[active]", "{$subscribe_config['active']}" ) );
showRow( $lang['opt_sys_ht'], $lang['opt_sys_htd'], "<input type=\"text\" class=\"form-control\" name=\"save_con[home_title]\" value=\"{$subscribe_config['home_title']}\">" );
showRow( $lang['subsc_amail'], $lang['subsc_amaild'], "<input type=\"text\" class=\"form-control\" name=\"save_con[mail]\" value=\"{$subscribe_config['mail']}\">" );
showRow( $lang['opt_sys_hu'], $lang['opt_sys_hud'], "<input type=\"text\" class=\"form-control\" name=\"save_con[http_home_url]\" value=\"{$subscribe_config['http_home_url']}\">" );
showRow( $lang['opt_sys_ct'], "<a onclick=\"javascript:Help('date'); return false;\" href=\"#\">$lang[opt_sys_and]</a>", "<input  type=\"text\" class=\"form-control\" style=\"max-width:150px; text-align: center;\" name='save_con[timestamp]' value=\"{$subscribe_config['timestamp']}\">" );
showRow( $lang['allow_wysiwyg'], $lang['allow_wysiwyg_help'], makeDropDown( array ("1" => "On", "0" => "Off" ), "save_con[allow_wysiwyg]", "{$subscribe_config['allow_wysiwyg']}" ) );
echo <<<HTML
</table>
<div class="panel-footer" style="margin-bottom:30px;">
<input type="hidden" name="user_hash" value="{$dle_login_hash}" />
<button type="submit" class="btn bg-teal btn-raised position-left"><i class="fa fa-floppy-o position-left"></i>{$lang['user_save']}</button>
</div>
</div></div>
</form>
HTML;

echo <<<HTML
<form action="?mod=subscribeusers&action=sending" method="post">
<div class="panel panel-default">
  <div class="panel-heading">
    {$lang['panel_subscribeuserssendmail']}
    <div class="heading-elements">
			<div class="form-group has-feedback" >

   <label> <input class="switch" type="checkbox" name="master_box" id="cc" title="{$lang['edit_selall']}" onclick="javascript:checkAll(this)">   {$lang['edit_selall']}</label>
			</div>
		</div>
  </div>
  <div class="table-responsive">
  <table class="table table-striped">
<tr>
<td>
{$entries}
</td>
</tr>
  
<script>
function checkAll(o) {
  var boxes = document.getElementsByTagName("input");
  for (var x = 0; x < boxes.length; x++) {
    var obj = boxes[x];
    if (obj.type == "checkbox") {
      if (obj.name != "check")
        obj.checked = o.checked;
    }
  }
}
</script>
<style>
.checkbox {
  margin-right: 1rem;
  padding-left: 1.75rem;
   line-height: 12px;
    font-weight: 500;
    margin-block: 10px;
  position: relative;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}
.checkbox input[type=checkbox] {
  position: absolute;
  opacity: 0;
}
.checkbox input[type=checkbox]:focus ~ span {
  border: 2px solid #aab0b9;
}
.checkbox input[type=checkbox]:focus:checked ~ span {
  border: 2px solid #20644c;
}
.checkbox input[type=checkbox]:checked ~ span {
  color: #FFFFFF;
  background: #20644c url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+DQo8c3ZnIHdpZHRoPSIxMiIgaGVpZ2h0PSI5IiB2aWV3Qm94PSIwIDAgMTIgOSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCiAgPHBhdGggZD0iTTQuNTc1IDguOTc3cy0uNDA0LS4wMDctLjUzNi0uMTY1TC4wNTcgNS42NGwuODI5LTEuMjI3TDQuNDcgNy4yNjggMTAuOTIxLjA4NmwuOTIzIDEuMTAzLTYuODYzIDcuNjRjLS4xMzQtLjAwMy0uNDA2LjE0OC0uNDA2LjE0OHoiIGZpbGw9IiNGRkYiIGZpbGwtcnVsZT0iZXZlbm9kZCIvPg0KPC9zdmc+) 50% 40% no-repeat;
  border: 2px solid #20644c;
}
.checkbox span {
  border-radius: 3px;
  position: absolute;
  left: 0;
  top: -2px;
  width: 1rem;
  height: 1rem;
  background-color: #d4d7dc;
  border: 2px solid #d4d7dc;
  pointer-events: none;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}
  </style>
<tr>
	<td><div class="form-group">
  <label class="control-label col-sm-2">{$lang['subject']} </label>
  <div class="col-sm-10">
     <input type="text" class="form-control width-500" name="subject" placeholder="{$lang['subject']}" value=""> 
  </div>
</div></td>
</tr>
<tr>
	<td>
<div class="form-group editor-group">

							  <label class="control-label col-md-2">{$lang['masgd']}</label>

							  <div class="col-md-10">

HTML;
if( $subscribe_config['allow_wysiwyg'] == '1') {

		

		include (DLEPlugins::Check(ENGINE_DIR . '/editor/subscribe.php'));

	

	} else {

	
		echo <<<HTML

		<div class="editor-panel"><div class="shadow-depth1">{$bb_code}<textarea class="editor" style="width:100%;height:350px;" name="message" id="message" onfocus="setFieldName(this.name)"></textarea></div></div><script>var selField  = "message";</script>

HTML;

	

	}


	echo <<<HTML
</div>
</div>
	
	</td>
</tr>
</table>
<div class="panel-footer" style="margin-bottom:30px;">
<input type="hidden" name="user_hash" value="{$dle_login_hash}" />
<button type="submit" class="btn bg-teal btn-raised position-left"><i class="fa fa-floppy-o position-left"></i>{$lang['user_save']}</button>
</div>
</div></div>
</form>
HTML;

if(!is_writable(ENGINE_DIR . '/data/config.subscribe.php')) {

	$lang['stat_system'] = str_replace ("{file}", "engine/data/config.subscribe.php", $lang['stat_system']);

	echo "<div class=\"alert alert-warning alert-styled-left alert-arrow-left alert-component\">{$lang['stat_system']}</div>";

}

echofooter();
?>



