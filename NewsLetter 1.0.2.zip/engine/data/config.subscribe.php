<?PHP 

////Subscribe form Configurations

$subscribe_config = array (


);

?>